import java.util.Scanner;



public class ImperialMetric {



    public static void main(String[] args) {



        int minNumber, maxNumber;

        float meter;

        float feetToMeter, inchToMeter;



        Scanner sc = new Scanner(System.in);



        System.out.println("Enter the minimum number of feet (not less than 0):");

        minNumber = sc.nextInt();



        System.out.println("Enter the maximum number of feet (not more than 30):");

        maxNumber = sc.nextInt();


        int[] inches = new int[12];



        int[] feets = new int[maxNumber];

        System.out.print(" |");



        for (int i = 0; i < 12; i++) {



            System.out.print(String.format("%5s", i) + "\"");

        }



        System.out.println();

// first for loop for rows this loop start with minimum and end with maximum

// value from user input

        for (int i = minNumber; i <= feets.length; i++) {

// print the value 0 to 30

            if (i >= 0 && i <= 9) {

                System.out.print(i + "' | ");

            } else {

                System.out.print(i + "'| ");

            }



            for (int j = 0; j < inches.length; j++) {



                feetToMeter = (float) (i * 0.3048);



                inchToMeter = (float) (j * 0.0254);



                meter = feetToMeter + inchToMeter;



                System.out.printf("%.3f", meter);

                System.out.print(" ");

            }


            System.out.println(" ");

        }

    }

}

