public class PalinPerfect {
}
import java.util.Scanner;

public class PalinPerfect {

    public static boolean isPalindrome(int num) {
        String str = String.valueOf(num);
        String reverse = "";
        for(int i = str.length()-1; i >=0 ; i--){
            reverse += str.charAt(i);
        }
        return str.equals(reverse);
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the starting point N:");
        int start = in.nextInt();
        System.out.println("Enter the ending point M:");
        int end = in.nextInt(), temp;
        if(start < end) {
            System.out.println("The palindromic perfect squares are as follows:");
            for (int i = start; i < end; i++) {
                temp = (int) Math.sqrt(i);
                if (temp * temp == i && isPalindrome(i)) {
                    System.out.println(i);
                }
            }
        }
    }

}