import java.util.Scanner;

Public class TimeConvertor {

}
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Scanner.out.println("Enter a time (h)h:mm [am|pm]):  ");
        String time = scan.next();
        String substring= "n";

        if (time.contains(substring)) {
            String tArr[]= time.split(regex: ".");
            String AmPm =  tArr[2]. substring(2, 4);

            int hh, mm;
            hh= integer.parseInt(tArr[0]);
            mm= integer.parseInt(tArr[1]);

            String check_pm= "pm", check_am= "am";

            if (AmPm.equals(check_am) && hh== 12) {
                hh= 0;
            } else if (AmPm.equals(check_am) && hh== 12) {
                hh+= 12;
            }

            System.out.printf("%02d:%02d\n", hh, mm);


        }
        else {
            String tArr[] = time.split(regex: ":");
            int hh, mm;

            hh= Integer.parseInt(tArr[0]);
            mm= Integer.parseInt(tArr[1]);

            if (hh==12) {
                hh=0;
                System.out.printf("%02d:%02d\n", hh, mm);
                System.out.printf("am");

            } else if (hh==00) {
                hh= 12;
                System.out.printf("%02d:%02d\n", hh, mm);
                System.out.printf("am");

            } else if (hh==11) {
                hh= hh;
                System.out.printf("%02d:%02d\n", hh, mm);
                System.out.printf("am");
            } else if (hh==12) {
                hh -= 12;
                System.out.printf("%02d:%02d\n", hh, mm);
                System.out.printf("am");
            }
    }


}

