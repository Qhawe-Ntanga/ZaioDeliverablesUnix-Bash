import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class CowsandBullsGame{
    public static void main(String[] args){
        Random rand= new Random();
        int targt= 0;
        while(hasDupes(targt= (rand.nextInt(9000) + 1000)));
        String targtStr = targt +"";
        boolean predicted = false;
        Scanner in = new Scanner(System.in);
        int predictions = 0;
        do{
            int BUlls = 0;
            int CowS = 0;
            System.out.print("Guess a 4-digit number with no duplicate digits: ");
            int predict;
            try{
                predict = in.nextInt();
                if(hasDupes(predict) || predict < 1000) continue;
            }catch(InputMismatchException e){
                continue;
            }
            predictions++;
            String predictStr = predict + "";
            for(int i= 0;i < 4;i++){
                if(predictStr.charAt(i) == targtStr.charAt(i)){
                    BUlls++;
                }else if(targtStr.contains(predictStr.charAt(i)+"")){
                    CowS++;
                }
            }
            if(BUlls == 4){
                predicted = true;
            }else{
                System.out.println(CowS+" Cows and "+BUlls+" Bulls.");
            }
        }while(!predicted);
        System.out.println("You won after "+predictions+" predictions!");
    }

    public static boolean hasDupes(int num){
        boolean[] Digits = new boolean[10];
        while(num > 0){
            if(Digits[num%10]) return true;
            Digits[num%10] = true;
            num/= 10;
        }
        return false;
    }
}
