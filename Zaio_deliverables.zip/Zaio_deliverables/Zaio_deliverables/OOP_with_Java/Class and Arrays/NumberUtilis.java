public class NumberUtils {

    private NumberUtils() { }


    public static int[] toArray(int number) {



        String numString = Integer.toString(number);
        int[] myArray = new int[numString.length()];

        for (int i = 0; i < numString.length(); i++) {
            char c = numString.charAt(i);

            int cVal = Character.getNumericValue(c);

            myArray[i] = cVal;
        }
        return myArray;
    }


    public static int countMatches(int a, int b) { //Bulls


        int count = 0;

        char[] arrayA = Integer.toString(a).toCharArray();
        char[] arrayB = Integer.toString(b).toCharArray();

        for (int i = 0; i < Math.min(arrayA.length,arrayB.length); i++) {
            if (arrayA[i] == arrayB[i])
                count += 1;
        }
        return count;
    }

    public static int countIntersect(int numA, int numB) { //Cows

        int count = 0;

        char[] arrayA = Integer.toString(numA).toCharArray();
        char[] arrayB = Integer.toString(numB).toCharArray();

        for (int i = 0; i < arrayA.length; i++) {
            for (int j = i; j < arrayB.length; j++) {
                if (arrayA[i] == arrayB[j]) {
                    if(i != j) {
                        count++;
                    }
                    break;
                }
            }
        }
        return count;
    }
}
