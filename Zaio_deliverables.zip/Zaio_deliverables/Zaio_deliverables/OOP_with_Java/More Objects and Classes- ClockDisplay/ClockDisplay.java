class ClockDisplay
{
    private CounterDisplay hours;
    private CounterDisplay minutes;
    //set the hours and the minutes of the clock
    public ClockDisplay(int pHours, int pMinutes)
    {
        hours = new CounterDisplay(24);
        hours.setValue(pHours);
        minutes = new CounterDisplay(60);
        minutes.setValue(pMinutes);

    }
    //To set the time
    public void setTime(int pHours, int pMinutes)
    {
        hours.setValue(pHours);
        minutes.setvalue(pMinutes);

    }
    public void tick()
    {
        minutes.increment();
        if(minutes.getValue()==0)
        {
            hours.increment();

        }
    }

    //to display the time in two digits
    public String getDisplayValue()
    {
        string time_str;
        if(hour.getValue()<12&&minutes.getValue()<10)

            time_str = "0"+hours.getValue()+ ":0" +minutes.getValue();
        if(hours.getValue()<12)

            time_str = "0"+hours.getValue()+ ":" +minutes.getValue();
        else if(minutes.getValue()<10);

        time_str = hours.getValue()+ ":0" +minutes.getValue();
            else
        time_str = hours.getValue()+ ":" +minutes.getValue();

        return time_str;

    }

}


public class ClockImp
{
    //the main method
    public static void main(String[] args)

    {
        ClockDisplay clockDisplay = new  ClockDisplay(5,30);
        clockDisplay.tick();

        System.out.println(clockDisplay.getDisplayValue());
        CounterDisplay CounterDisplay  = new CounterDisplay(3);

        clockDisplay.tick();
        clockDisplay.tick();

        System.out.println(counterDisplay.getDisplayValue());
        clockDisplay.tick();

        System.out.println(counterDisplay.getDisplayValue());




    }
}

import java.util.*;
        import java.lang.*;
//  Class CounterDisplay
class CounterDisplay{

    private int value;
    private int limit;
    public CounterDisplay(int pLimit)
    {
        value = 0;
        limit = pLimit;
    }
    public void setValue(int pValue)
    {
        value =  pValue;

    }
    public int getValue()

    {
        return value;
    }
    public void increment()
    {
        value = value+1;
        if(value>limit)
            value = 0;
    }
    public String getDisplayValue()
    {
        String counterStr;
        counterStr = "0"+getValue();
        return counterStr;
    }

}
