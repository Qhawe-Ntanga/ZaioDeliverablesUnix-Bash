import java.util.*;

class Vehicle {
    private int numPassengers;
    private String colour;

    Vehicle(int passengers, String colour) {
        this.numPassengers = passengers;
        this.colour = colour;
    }

    public String toString() {
        return colour + " " + numPassengers + " passengers";
    }
}


class Car extends Vehicle
{
    int doors;
    // System.out.println (new Car ("Black", 4, 4));
    Car(String color,int passenger,int doors)
    {
        super(passenger,color);
        this.doors=doors;
    }
    @Override
    public String toString() {
        return super.toString()+" "+doors+" doors";
    }

}

class plane extends Vehicle
{
    //System.out.println (new Plane ("White", 416, "Boeing", 737));

    String manufact;
    int model_num;
    plane(String color,int doors,String manufactoror,int model_n)
    {
        super(doors,color);
        this.manufact=manufactoror;
        this.model_num=model_n;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return super.toString()+" "+manufact+" "+model_num;
    }


}


public class Question1
{
    public static void main ( String args [] )
    {
        System.out.println (new Vehicle (2, "Blue"));
        System.out.println (new Car ("Black", 4, 4));
        System.out.println (new plane ("White", 416, "Boeing", 737));
    }
}
