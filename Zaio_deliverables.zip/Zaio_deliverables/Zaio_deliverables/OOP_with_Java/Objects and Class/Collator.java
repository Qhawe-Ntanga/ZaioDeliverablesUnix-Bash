public class Collator {
    private String label;

    private int numReadings;
    private int total;
    private int maximum;
    private int minimum;

    Collator(String label) {
        this.label = label;
        numReadings = 0;
        total = 0;
        maximum = 0;
        minimum = 0;
    }

    void label(String label) {
        this.label = label;
    }

    String label() {
        return label;
    }

    void recordReading(int reading) {
        if (numReadings < 1) {

            total = reading;
            maximum = reading;
            minimum = reading;
            numReadings = 1;
        } else {

            total = total + reading;
            numReadings++;


            if (reading > maximum) {
                maximum = reading;
            }


            if (reading < minimum) {
                minimum = reading;
            }
        }
    }

    public int maximum() {
        return maximum;
    }

    public int minimum() {
        return minimum;
    }

    public double average() {
        return total / (double) numReadings;
    }

    public int numberOfReadings() {
        return numReadings;
    }

}
Meteorology class:
        --------------------------------------------------------------------------
        import java.util.Scanner;

public class Meteorology {
    public static void main(String[] args) {


        Collator temperature = new Collator("temperature");
        Collator pressure = new Collator("pressure");
        Collator humidity = new Collator("humidity");


        System.out.println("Meteorology Program");
        Scanner keyboard = new Scanner(System.in);
        int option;
        do {
            System.out.println("Make selection process and press return");
            System.out.println("1. Record temperature reading");
            System.out.println("2. Record pressure reading");
            System.out.println("3. Record humidity reading");
            System.out.println("4. Print maximum values");
            System.out.println("5. Print minimum values");
            System.out.println("6. Print average values");
            System.out.println("7. Quit");
            option = keyboard.nextInt();
            switch (option) {
                case 1:
                    System.out.println("Enter value:");
                    temperature.recordReading(keyboard.nextInt());
                    break;
                case 2:
                    System.out.println("Enter value:");
                    pressure.recordReading(keyboard.nextInt());
                    break;
                case 3:
                    System.out.println("Enter value:");
                    humidity.recordReading(keyboard.nextInt());
                    break;
                case 4:
                    System.out.println("Maximum temperature:" + (temperature.numberOfReadings() == 0 ? "-" : temperature.maximum()));
                    System.out.println("Maximum pressure:" + (pressure.numberOfReadings() == 0 ? "-" : pressure.maximum()));
                    System.out.println("Maximum humidity:" + (humidity.numberOfReadings() == 0 ? "-" : humidity.maximum()));
                    break;
                case 5:
                    System.out.println("Minimum temperature:" + (temperature.numberOfReadings() == 0 ? "-" : temperature.minimum()));
                    System.out.println("Minimum pressure:" + (pressure.numberOfReadings() == 0 ? "-" : pressure.minimum()));
                    System.out.println("Minimum humidity:" + (humidity.numberOfReadings() == 0 ? "-" : humidity.minimum()));
                    break;
                case 6:
                    System.out.println("Average temperature:" + (temperature.numberOfReadings() == 0 ? "-" : temperature.average()));
                    System.out.println("Average pressure:" + (pressure.numberOfReadings() == 0 ? "-" : pressure.average()));
                    System.out.println("Average humidity:" + (humidity.numberOfReadings() == 0 ? "-" : humidity.average()));
                    break;
            }
        } while (option != 7);
        keyboard.close();
    }
}
    Sample output screenshot(for demonstration):
        Meteorology Program Make selection process and press return 1. Record temperature reading 2. Record pressure reading 3. Record humidity reading 4. Print maximum values 5. Print minimumvalues 6. Print average values 7. Quit 1 Entervalue: 17 Make selection process and press return 1. Record temperature reading 2. Record pressure reading 3. Record humidity reading 4. Print maximumvalues 5. Print minimum values 6. Print average values 7. Quit 4 Maximum temperature : 17 Maximum pressure:- Maximum humidity:
//--------------------------------------------------------------------------
//Updated Meteorology class
        import java.util.Scanner;

public class Meteorology {
    public static void main(String[] args) {


        Collator temperature = new Collator("temperature");
        Collator pressure = new Collator("pressure");
        Collator humidity = new Collator("humidity");


        System.out.println("Meteorology Program");
        Scanner keyboard = new Scanner(System.in);
        int option;
        do {
            System.out.println("Make selection process and press return");
            System.out.println("1. Record temperature reading");
            System.out.println("2. Record pressure reading");
            System.out.println("3. Record humidity reading");
            System.out.println("4. Print maximum values");
            System.out.println("5. Print minimum values");
            System.out.println("6. Print average values");
            System.out.println("7. Quit");
            option = keyboard.nextInt();
            switch (option) {
                case 1:
                    System.out.println("Enter value:");
                    temperature.recordReading(keyboard.nextInt());
                    break;
                case 2:
                    System.out.println("Enter value:");
                    pressure.recordReading(keyboard.nextInt());
                    break;
                case 3:
                    System.out.println("Enter value:");
                    humidity.recordReading(keyboard.nextInt());
                    break;
                case 4:
                    System.out.println("Maximum temperature: " + (temperature.numberOfReadings() == 0 ? "-" : temperature.maximum()));
                    System.out.println("Maximum pressure: " + (pressure.numberOfReadings() == 0 ? "-" : pressure.maximum()));
                    System.out.println("Maximum humidity: " + (humidity.numberOfReadings() == 0 ? "-" : humidity.maximum()));
                    break;
                case 5:
                    System.out.println("Minimum temperature: " + (temperature.numberOfReadings() == 0 ? "-" : temperature.minimum()));
                    System.out.println("Minimum pressure: " + (pressure.numberOfReadings() == 0 ? "-" : pressure.minimum()));
                    System.out.println("Minimum humidity: " + (humidity.numberOfReadings() == 0 ? "-" : humidity.minimum()));
                    break;
                case 6:
                    if (temperature.numberOfReadings() == 0)
                        System.out.println("Average temperature: -");
                    else
                        System.out.printf("Average temperature: %.2f\n", temperature.average());

                    if (pressure.numberOfReadings() == 0)
                        System.out.println("Average temperature: -");
                    else
                        System.out.printf("Average temperature: %.2f\n", pressure.average());

                    if (humidity.numberOfReadings() == 0)
                        System.out.println("Average temperature: -");
                    else
                        System.out.printf("Average temperature: %.2f\n", humidity.average());
                    break;
            }
        } while (option != 7);
        keyboard.close();
    }
}

}
