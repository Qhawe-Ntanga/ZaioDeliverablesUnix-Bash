public class Student {


    private String first;
    private String middle;
    private String last;


    public void setNames(String first, String middle, String last) {
        this.first  = first;
        this.middle = middle;
        this.last = last;
    }



    public String getFullName() {
        return first + " " + middle.charAt(0) + ". " + last;
    }

}



public class TestStudent {

    public static void main(final String[] args) {

        System.out.println("Test 1");
        Student student = new Student();
        student.setNames("Patricia", "Nombuyiselo", "Noah");
        if (student.getFullName().equals("Patricia N. Noah")) {
            System.out.println("Pass");
        }
        else {
            System.out.println("Fail");
        }


        System.out.println("Test 2");
        student = new Student();
        student.setNames("Nomalizo", "Frances", "Noah");
        if (student.getFullName().equals(student.getFullName())) {
            System.out.println("Pass");
        }
        else {
            System.out.println("Fail");
        }

    }

